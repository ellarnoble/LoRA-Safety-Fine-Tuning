# Model condition scripts

Refactored versions of the LoRA-rank / adapter-placement experiment scripts,
wired into your existing `config.py`. The old layout was one hand-edited copy
of each script per model (`Mistral_LoRA.py`, `Qwen_LoRA.py`, `Falcon_LoRA.py`,
...), so switching conditions meant manually changing `model_id`,
`output_dir`, and `layers_to_transform` every time. This version replaces
those with:

- one script per **pipeline stage** (LoRA fine-tune, full fine-tune,
  generate, LlamaGuard evaluate), each taking `--model`/`--rank`/`--placement`/
  `--condition` as command-line arguments
- everything path- and constant-related read from `config.py` -- the system
  prompt, base model paths, and the early/middle/late layer table from the
  dissertation (Table `tab:model-layer-placements`) all live there once,
  alongside your `DATA_ROOT`/`BASE_MODEL_ROOT`/`LORA_ROOT`/`FULL_FT_ROOT`/
  `EVAL_OUTPUT_ROOT` roots
- SLURM job templates + submission scripts that loop over all 42 conditions
  for you

Nothing about the underlying training/generation logic changed -- this is a
straight refactor, not a re-implementation. The only genuine per-model
difference that survived (Falcon needing manual `generate()` + turn-marker
truncation instead of `pipeline()`, because its `<|user|>`/`<|assistant|>`/
`<|system|>` markers aren't real special tokens) is now handled automatically
by `generate.py` based on `config.MODEL_REGISTRY[model].generation_mode`, so
you don't need to remember which model needs which code path.

## Setup

Edit `USERNAME` at the top of `config.py` (and any of the `*_ROOT` paths, if
your layout differs from CSF3 scratch) -- that's the only file anyone
cloning the repo needs to touch. Everything else imports from it.

`config.py` additions beyond what you already had:

| Name | Purpose |
|---|---|
| `TRAIN_FILE`, `TEST_FILE` | `DATA_ROOT / "train.jsonl"` and `DATA_ROOT / "test.jsonl"` |
| `GENERATE_ROOT` | Where `generate.py` writes `*_responses.jsonl`, one subfolder per model |
| `LLAMA_GUARD_MODEL_ROOT` | LlamaGuard checkpoint path |
| `SYSTEM_PROMPT` | The safety-classification system prompt, shared by fine-tuning and generation |
| `MODEL_REGISTRY` | Per-model base path, layer count, early/middle/late ranges, generation mode |
| `RANKS`, `PLACEMENTS`, `DEFAULT_LORA_ALPHA` | The 4x3 LoRA design |
| helper functions | `placement_layers`, `lora_output_dir`, `full_output_dir`, `resolve_model_dir`, `generate_output_file`, `safety_eval_paths`, `all_conditions`, plus the shared prompt-formatting / JSON-safety helpers used by `generate.py` |

LlamaGuard safety-eval results now live under `EVAL_OUTPUT_ROOT/safety/<model>/`,
alongside wherever your IFEval/MMLU capability results go, instead of next to
the `generate.py` output files.

## Files

```
config.py                your existing central config, extended (see Setup above)
lora_finetune.py          python lora_finetune.py --model mistral7b --rank 4 --placement early
full_finetune.py          python full_finetune.py --model mistral7b
generate.py               python generate.py --model mistral7b --condition lora --rank 4 --placement early
llamaguard_evaluate.py    python llamaguard_evaluate.py --model mistral7b --condition lora --rank 4 --placement early

slurm/train_lora.sbatch      job template (needs MODEL, RANK, PLACEMENT via --export)
slurm/train_full.sbatch      job template (needs MODEL via --export)
slurm/generate.sbatch        job template (needs MODEL, CONDITION[, RANK, PLACEMENT])
slurm/evaluate.sbatch        job template (needs MODEL, CONDITION[, RANK, PLACEMENT])

submit_all_lora.sh       queues all 36 LoRA jobs (3 models x 4 ranks x 3 placements)
submit_all_full.sh       queues all 3 full-fine-tune jobs
submit_all_generate.sh   queues generation for all 42 conditions
submit_all_evaluate.sh   queues LlamaGuard evaluation for all 42 conditions
```

## One-off runs (no SLURM)

```bash
# LoRA fine-tune: rank 16, middle layers, Qwen
python lora_finetune.py --model qwen7b --rank 16 --placement middle

# Full fine-tune, Mistral
python full_finetune.py --model mistral7b

# Generate responses for that LoRA run
python generate.py --model qwen7b --condition lora --rank 16 --placement middle

# Generate the baseline (no fine-tuning) responses
python generate.py --model qwen7b --condition baseline

# Evaluate with LlamaGuard -- input/output/debug paths all derived from
# config.py automatically
python llamaguard_evaluate.py --model qwen7b --condition lora --rank 16 --placement middle
```

`llamaguard_evaluate.py` also accepts `--input`/`--output`/`--debug` directly
(all three required together, without `--model`/`--condition`) for
evaluating an arbitrary file that doesn't follow the `config.py` layout.

Every script prints its resolved paths at startup, so you can sanity-check a
condition before it burns GPU time.

## Running the full 42-condition sweep on SLURM

**First, edit the `#SBATCH` lines in the four files under `slurm/`** --
partition, account, GPU/CPU/memory request and time limit are left as
placeholders (`# TODO`) since they depend on your cluster. Also uncomment
and fill in the `module load` / `source .../activate` lines.

```bash
# 1. Fine-tune (36 LoRA + 3 full = 39 training jobs)
./submit_all_lora.sh
./submit_all_full.sh

# 2. Once training finishes, generate responses for all 42 conditions
#    (baseline needs no training job to finish first)
./submit_all_generate.sh

# 3. Once generation finishes, evaluate all 42 conditions with LlamaGuard
./submit_all_evaluate.sh
```

Add `--dry-run` to any `submit_all_*.sh` to print the `sbatch` commands
instead of submitting them -- useful for checking the condition list or
copy-pasting a single command.

If your cluster supports job dependencies and you want the generate/evaluate
steps to wait on a specific job automatically:

```bash
DEPEND=afterok:123456 ./submit_all_generate.sh
```

(This applies the same dependency to every job in the batch -- fine when you
train/generate/evaluate as three separate sequential waves. If you want a
tighter one-condition-depends-on-its-own-training-job chain, capture each
`sbatch` job ID from `submit_all_lora.sh`/`submit_all_full.sh` and pass it
through per-condition; the scripts are short enough to adapt for that if you
need it.)

## Changing the LoRA alpha policy

`config.DEFAULT_LORA_ALPHA = 8` is used for every rank (1, 4, 16, 64), matching
what the original r=1 pilot script used. Override per-run with
`--alpha <value>` on `lora_finetune.py`, or edit `DEFAULT_LORA_ALPHA` in
`config.py` if you want a different fixed value everywhere. If you later
decide to scale alpha with rank instead (e.g. alpha = 2 x rank), that's a
one-line change in `submit_all_lora.sh` (compute `ALPHA` per rank in the loop)
plus passing it through `--alpha "$ALPHA"` as it already does.

## Adding a fourth model

1. Add its entry to `MODEL_REGISTRY` in `config.py`: base path, total layer
   count, early/middle/late ranges, and `generation_mode` (`"pipeline"` unless
   it has the same non-special-token turn-marker quirk Falcon has, in which
   case `"manual"`).
2. Add it to the `MODELS=(...)` array in each `submit_all_*.sh`.

Nothing else needs to change -- `lora_finetune.py`, `full_finetune.py`,
`generate.py`, and `llamaguard_evaluate.py` all read from the registry.
